package control;

public class Config {
    private static final String SALT = "DD58eS$@ss";
    private static final String SENHAPADRAO = "123456";

    public static String getSALT() {
        return SALT;
    }

    public static String getSENHAPADRAO() {
        return SENHAPADRAO;
    }
}
